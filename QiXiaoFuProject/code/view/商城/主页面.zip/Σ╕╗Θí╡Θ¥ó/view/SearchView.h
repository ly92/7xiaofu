//
//  SearchView.h
//  QiXiaoFuProject
//
//  Created by mac on 2017/2/21.
//  Copyright © 2017年 fhj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SearchView : NSObject

@end
