//
//  ShopDetaileViewController.h
//  QiXiaoFuProject
//
//  Created by mac on 16/9/3.
//  Copyright © 2016年 fhj. All rights reserved.
//

#import "BaseViewController.h"

@interface ShopDetaileViewController : BaseViewController
@property (nonatomic,copy)NSString * goods_id;

@property (nonatomic,copy)NSString * goods_image;


@end
