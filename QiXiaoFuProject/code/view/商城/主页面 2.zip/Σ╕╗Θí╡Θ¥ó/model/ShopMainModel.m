//
//  ShopMainModel.m
//  QiXiaoFuProject
//
//  Created by mac on 16/9/26.
//  Copyright © 2016年 fhj. All rights reserved.
//

#import "ShopMainModel.h"

@implementation ShopMainModel


+ (NSDictionary *)objectClassInArray{
    return @{@"banner_list" : [Banner_List class], @"class_list" : [Class_List class]};
}

@end


@implementation Banner_List

@end


@implementation Class_List

@end


