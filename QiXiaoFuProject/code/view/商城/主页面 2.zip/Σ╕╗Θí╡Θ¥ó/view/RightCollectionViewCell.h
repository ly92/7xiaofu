//
//  RightCollectionViewCell.h
//  Group
//
//  Created by randy on 16/3/1.
//  Copyright © 2016年 Randy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightCollectionViewCell : UICollectionViewCell
@property (strong, nonatomic) IBOutlet UIImageView *collectionView_imageview;
@property (strong, nonatomic) IBOutlet UILabel *collectionView_Label;

@end
