//
//  LeftTableViewCell.h
//  Group
//
//  Created by randy on 16/3/1.
//  Copyright © 2016年 Randy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *tableview_textLabel;

@end
