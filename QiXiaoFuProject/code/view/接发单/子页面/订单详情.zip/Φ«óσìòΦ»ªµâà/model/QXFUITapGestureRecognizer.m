//
//  QXFUITapGestureRecognizer.m
//  QiXiaoFuProject
//
//  Created by mac on 16/11/8.
//  Copyright © 2016年 fhj. All rights reserved.
//

#import "QXFUITapGestureRecognizer.h"

@implementation QXFUITapGestureRecognizer

@end
