//
//  OrderDetailViewController.h
//  QiXiaoFuProject
//
//  Created by mac on 16/8/29.
//  Copyright © 2016年 fhj. All rights reserved.
//

#import "BaseViewController.h"

@interface OrderDetailViewController : BaseViewController
@property (nonatomic, copy) NSString *pro_id;// 项目

@property (nonatomic, assign) NSInteger type ;//  type 1 工程师  2  客户



@end
