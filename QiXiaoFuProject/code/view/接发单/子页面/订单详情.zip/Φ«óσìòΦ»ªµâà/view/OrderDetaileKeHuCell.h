//
//  OrderDetaileKeHuCell.h
//  QiXiaoFuProject
//
//  Created by mac on 16/10/19.
//  Copyright © 2016年 fhj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OrderDetaileKeHuCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *rightBtn;

@end
