//
//  RecommendEngineerListVC.m
//  QiXiaoFuProject
//
//  Created by mac on 16/8/30.
//  Copyright © 2016年 fhj. All rights reserved.
//

#import "RecommendEngineerListVC.h"
#import "EngineerEditListCell.h"
#import "EngineerDetaileViewController.h"


@interface RecommendEngineerListVC ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property(nonatomic, strong) NSMutableArray *dataArray;
@property(nonatomic, strong) NSMutableArray *deleteArr;//删除数据的数组
@property(nonatomic, strong) NSMutableArray *markArr;//标记数据的数组
@property(nonatomic, strong) UIButton *selectAllBtn;//选择按钮
@property(nonatomic, strong) UIView *baseView;//背景view
@property(nonatomic, strong) UIButton *deleteBtn;//删除
@property(nonatomic, strong) NSMutableArray *selectedRows;


@end

@implementation RecommendEngineerListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.deleteArr = [NSMutableArray array];
    self.markArr = [NSMutableArray array];

    
    
    //全选
    _selectAllBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    _selectAllBtn.frame = CGRectMake(0, 0, 60, 30);
    [_selectAllBtn setTitle:@"全选" forState:UIControlStateNormal];
    [_selectAllBtn addTarget:self action:@selector(selectAllBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithCustomView:_selectAllBtn];
    self.navigationItem.leftBarButtonItem = leftItem;
    _selectAllBtn.hidden = YES;

    
    self.navigationItem.title = @"推荐工程师";
    
    self.navigationItem.rightBarButtonItem= [UIBarButtonItem itemWithTitle:@"选择" target:self action:@selector(chooseItemAction:)];

    [_tableView registerNib:[UINib nibWithNibName:@"EngineerEditListCell" bundle:nil] forCellReuseIdentifier:@"EngineerEditListCell"];
    _tableView.tableFooterView = [UIView new];
    self.tableView.editing = NO;

    
//    [self addRefreshView];
    // Do any additional setup after loading the view from its nib.
}

- (void)chooseItemAction:(UIBarButtonItem *)item{
    
    self.tableView.allowsMultipleSelectionDuringEditing = YES;
    self.tableView.editing = !self.tableView.editing;

}
- (void)selectAllBtnClick:(UIButton *)item{
    
    for (int i = 0; i < self.dataArray.count; i ++) {
        
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
        [self.tableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionTop];
        [self.deleteArr addObjectsFromArray:self.dataArray];
    }
    NSLog(@"self.deleteArr:%@", self.deleteArr);
    
}






- (NSMutableArray *)dataArray {
    if (_dataArray == nil) {
        _dataArray = [NSMutableArray arrayWithArray:@[@"科比·布莱恩特",@"德里克·罗斯",@"勒布朗·詹姆斯",@"凯文·杜兰特",@"德怀恩·韦德",@"克里斯·保罗",@"德怀特·霍华德",@"德克·诺维斯基",@"德隆·威廉姆斯",@"斯蒂夫·纳什",@"保罗·加索尔",@"布兰顿·罗伊",@"奈特·阿奇博尔德",@"鲍勃·库西",@"埃尔文·约翰逊"]];
        
    }
    return _dataArray;
}




- (void)addRefreshView{
    
    
    [_tableView headerAddMJRefresh:^{
        
        
    }];
    [_tableView footerAddMJRefresh:^{
        
    }];
    
}
#pragma mark - UITableViewDelegate UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 10;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    EngineerEditListCell* cell = [tableView dequeueReusableCellWithIdentifier:@"EngineerEditListCell"];
    
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return  147;
}

//选中时将选中行的在self.dataArray 中的数据添加到删除数组self.deleteArr中
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.tableView.editing) {
        
        [self.deleteArr addObject:[self.dataArray objectAtIndex:indexPath.row]];
        
    }else{
        
//        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        EngineerDetaileViewController * vc  = [[EngineerDetaileViewController alloc]initWithNibName:@"EngineerDetaileViewController" bundle:nil];
        [self.navigationController pushViewController:vc animated:YES];
     }
    
}
//取消选中时 将存放在self.deleteArr中的数据移除
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath  {
     [self.deleteArr removeObject:[self.dataArray objectAtIndex:indexPath.row]];
}




- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10.0;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.001f;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
